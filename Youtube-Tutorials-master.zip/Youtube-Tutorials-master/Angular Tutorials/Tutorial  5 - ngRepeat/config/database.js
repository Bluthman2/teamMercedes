module.exports = {
	'url'	: 'mongodb://xxx:xxxxxxxxx@novus.modulusmongo.net:27017/yM5oryta'
}