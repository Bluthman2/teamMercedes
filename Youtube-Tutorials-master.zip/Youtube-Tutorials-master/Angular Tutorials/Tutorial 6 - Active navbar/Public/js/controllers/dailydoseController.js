myApp.controller('dailydoseController', ['$scope', function($scope){


}]);