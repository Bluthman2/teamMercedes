myApp.controller('submitController', ['$scope', function($scope){
	

}]);